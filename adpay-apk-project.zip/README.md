# AdPay BD Android App

Online WebView Android app for the AdPay BD website.

## GitHub Actions APK build

1. Upload the **contents of this project** to the root of a GitHub repository.
2. Make sure `.github/workflows/build-apk.yml` is uploaded too.
3. Open the repository's **Actions** tab.
4. Select **Build AdPay BD APK**.
5. Tap **Run workflow**.
6. After the run succeeds, open the run and download the **AdPayBD-debug-apk** artifact.

The app opens:
https://deluxe-duckanoo-0892da.netlify.app/

This APK is an online WebView wrapper. It does not itself implement server-side rewards, wallet accounting, rewarded-ad verification, or withdrawals.
